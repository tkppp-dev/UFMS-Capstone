package sj.sjesl.entity;

public enum MemberPrivileges {
    GUEST,STUDENT,PROFESSOR,ADMIN
}
